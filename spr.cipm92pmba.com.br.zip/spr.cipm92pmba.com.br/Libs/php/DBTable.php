<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of DBTable
 *
 * @author richard
 */
abstract class DBTable {
    //put your code here
    abstract public function getTable();
    abstract public function getPropriedades();
}
