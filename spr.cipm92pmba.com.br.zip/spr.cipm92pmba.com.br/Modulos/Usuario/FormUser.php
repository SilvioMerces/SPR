<label class="TituloForm">Cadastro de Usuário </label>
<div class="col col-2" >
    <form id="frmUsuario" method="POST" enctype="multipart/form-data" onsubmit="return false">
        <label for="foto">Foto</label><input type="file" id="foto" name="foto" value=""/>
        <label for="login">Login</label><input type="text" id="login" name="login" value=""/>
        <label for="cpf">CPF</label><input type="text" id="cpf" name="cpf" value=""/>
        <label for="pwd">Senha</label><input type="text" id="pwd" name="pwd" value=""/>
        <label for="perfil">Perfil</label><input type="text" id="perfil" name="perfil" value=""/>
        <label for="ativo">Status</label><input type="text" id="ativo" name="ativo" value=""/>
    </form> 
</div>